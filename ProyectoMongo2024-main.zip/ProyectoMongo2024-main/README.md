# ProyectoMongo2024

Proyecto para base de datos con mongodb
